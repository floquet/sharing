 .. _credits:

Credits
======================

PyKEP has been created by the PaGMO development Team at the European Space Agency and was once part of the project  `PaGMO/PyGMO <https://github.com/esa/pagmo>`_. As of the release 1.0 of PaGMO the decision was taken to move the entire keplerian_toolbox and its python alter-ego (PyKEP) to a different project and to keep supporting complete compatibility between the two projects.

PyKEP is in use at the European Space Agency's Advanced Concepts Team since 2006.

**Main Developers**:

Dario Izzo (madsax)

Francesco Biscani (bluescarni) 