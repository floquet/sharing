.. _howtodownload:

Download PyKEP code
======================

PyKEP source code is managed via the `keplerian_toolbox sourceforge project <http://sourceforge.net/projects/keptoolbox/>`_.
The `git <http://git-scm.com/>`_ versioning system is needed to access the code. 

* open a terminal and type::

    git clone https://github.com/esa/pykep.git
